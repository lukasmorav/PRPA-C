#include <stdio.h>
#include <stdlib.h>

void apppend (int *numbers, int new, int i)
{
    if (i == 0)
    {
        numbers[i] = new;
    }
    else if (new > numbers[i-1])
    {
        numbers[i] = new;
    }
    else
    {
        numbers[i] = numbers[i-1];
        apppend(numbers, new, --i);
    }
}

int main ()
{
    int columns;
    if (scanf("%i", &columns) != 1)
    {
        fprintf(stderr, "Error: Chyba histogramu!\n");
        return 100;
    }

    int i = 0;
    int *numbers = (int *)malloc(1 * sizeof(int));
    int max, min;

    while(1)
    {
        int holder;
        numbers = (int *)realloc(numbers, (i+1) * sizeof(int));
        if (scanf("%i", &holder) != 1)
        {
            break;
        }

        //Max-min solution
        if (i == 0) {max = min = holder;}
        else if (max < holder) {max = holder;}
        else if (min > holder) {min = holder;}

        apppend(numbers, holder, i);
        i++;
    }

    //Median solution
    int medianPos = i/2;
    if (medianPos - (int)medianPos == 0)
    {
        printf("Median %.2f\n", (float)numbers[medianPos]);
    }
    else
    {
        printf("Median %.2f\n", (float)(numbers[(int)medianPos] + numbers[(int)medianPos+1])/2);
    }
    
    printf("Pocet cisel: %i\n", i);
    printf("Min. hodnota: %i\n", min);
    printf("Max. hodnota: %i\n", max);
    
    free(numbers);

    return 0;
}
